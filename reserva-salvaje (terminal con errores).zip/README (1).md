# Reserva Salvaje

Proyecto Integrador - Videojuego con persistencia en MySQL (Java, JDBC, DAO).

Juego de gestión: el jugador administra una reserva de rescate de animales con un presupuesto
limitado. Rescata animales, los aloja en el hábitat correcto, los alimenta y los cura, y cuando
se recuperan los libera. Cada día que pasa los animales tienen más hambre y la reserva recibe
donaciones según cuántos animales sanos tiene.

## Requisitos

- Java 17 o superior (JDK)
- MySQL 8.4 LTS (funciona también con 8.0)
- VS Code con "Extension Pack for Java" (o cualquier IDE que soporte Maven)

## Cómo ejecutarlo

1. Ejecutar el script `sql/schema.sql` en MySQL.
2. Poner usuario y contraseña de MySQL en `src/main/java/dao/ConexionDB.java`
   (o con las variables de entorno `DB_USER` y `DB_PASSWORD`).
3. Ejecutar la clase `main.Main` (botón Run en VS Code, o `mvn compile exec:java`).

El Main reinicia la partida cada vez que arranca (vacía la tabla `animal` y vuelve el presupuesto
a 1000), así que se puede ejecutar todas las veces que haga falta.

## Estructura

    sql/schema.sql                       tablas animal (tabla única con columna tipo) y reserva
    src/main/java/model/                 Animal y subclases, Cuidable, TipoHabitat, TipoAnimal, Reserva
    src/main/java/dao/                   ConexionDB, AnimalDAO, ReservaDAO
    src/main/java/service/               ReservaService (reglas de negocio)
    src/main/java/exception/             ReservaException (base) y las 7 excepciones del juego
    src/main/java/main/Main.java         flujo completo + errores forzados a propósito

## Jerarquía del modelo

`Animal` (abstracta) comparte identidad, salud, hambre y hábitat. Cada subclase resuelve algo
distinto: cuánto cuesta mantenerla por día, cuánto cuesta rescatarla, qué hábitat exige y cuánta
hambre calma una ración.

| Clase | Hábitat que exige | Costo diario |
|---|---|---|
| Carnivoro | JAULA_SEGURIDAD (aislado) | kg de carne x precio de la carne (el más alto) |
| Herbivoro | SABANA | kg de forraje x precio del forraje |
| Ave | AVIARIO | base + envergadura; más caro si no puede volar |
| Reptil | TERRARIO | base + temperatura ideal |
| AnimalAcuatico | ACUARIO | base + profundidad mínima |

La interfaz `Cuidable` (alimentar, curar, necesitaAtencion, calcularCostoDiario) la implementa
`Animal`. El service la usa de forma polimórfica en `atenderAnimal(Cuidable)`.

## Reglas de negocio y excepciones

| Regla | Excepción |
|---|---|
| Rescatar, alimentar o curar requiere presupuesto suficiente | FondosInsuficientesException |
| Cada hábitat tiene capacidad máxima (sabana 4, jaula 2, aviario 3, terrario 3, acuario 2) | HabitatLlenoException |
| El animal solo puede alojarse en el hábitat que exige su especie | HabitatIncompatibleException |
| Toda operación sobre un id que no existe se rechaza | AnimalNoEncontradoException |
| Solo se libera a un animal con salud de 60 o más | AnimalEnfermoException |
| Los datos al rescatar deben ser válidos (nombre, edad, salud, hambre, valores propios) | DatosInvalidosException |
| Cualquier SQLException se traduce y se relanza | PersistenciaException |

Todas heredan de `ReservaException`.

## Qué muestra el Main

0. Reinicia la partida.
1. Rescata una de cada especie y algunos herbívoros más.
2. Fuerza errores de rescate: datos inválidos, hábitat incompatible, hábitat lleno, fondos insuficientes.
3. Lista los animales y ocupación de la sabana.
4. Alimenta y atiende a los que lo necesitan.
5. Fuerza errores de cuidado: animal enfermo, curar sin fondos, id inexistente (dos veces).
6. Pasa un día (hambre, pérdida de salud, donaciones).
7. Polimorfismo: atiende a un Herbivoro, un Ave y un AnimalAcuatico con el mismo método.
8. Cura y libera a Tuco.
9. Fuerza un error de base de datos (se salta la validación del service con salud 150).
10. Muestra el estado final.

Ningún error escapa sin capturar: el Main captura las excepciones del juego en cada paso, y si
no hay conexión a MySQL termina con un mensaje claro.

## Cambios respecto al guion (para justificar)

- Se agregó el enum `TipoAnimal`: es el valor de la columna `tipo` y evita textos sueltos repetidos.
- Se agregó la excepción base `ReservaException`, de la que heredan las siete excepciones.
- Se agregó `reiniciarJuego()` (con `AnimalDAO.eliminarTodos()`) para que el Main se pueda repetir.
- Se definieron los costos de rescate (carnívoro 200, herbívoro 100, ave 80, reptil 60, acuático 150)
  y los parámetros del juego (curar cuesta 40 y recupera 30 de salud; cada día suma 25 de hambre).
- `atenderAnimal(Cuidable)` alimenta; curar es una acción aparte (`curarAnimal`), porque la interfaz
  no distingue si la atención que necesita el animal es por hambre o por salud.
- `trasladarAnimal` del guion no se implementó: cada especie tiene un único hábitat válido, así que
  el jugador elige el hábitat al rescatar y el service valida que sea el correcto.
- `schema.sql` usa `CREATE TABLE IF NOT EXISTS` para poder ejecutarse más de una vez.
