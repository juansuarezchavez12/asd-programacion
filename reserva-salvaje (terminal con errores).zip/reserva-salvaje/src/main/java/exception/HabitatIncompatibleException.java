package exception;

import model.TipoAnimal;
import model.TipoHabitat;

/** Se intentó alojar a un animal en un hábitat que no es el que exige su especie. */
public class HabitatIncompatibleException extends ReservaException {

    private static final long serialVersionUID = 1L;

    public HabitatIncompatibleException(String nombre, TipoAnimal tipo, TipoHabitat elegido, TipoHabitat requerido) {
        super("'" + nombre + "' (" + tipo + ") no puede alojarse en " + elegido + ": necesita " + requerido);
    }
}
