package exception;

/** El animal no tiene la salud suficiente para ser liberado. */
public class AnimalEnfermoException extends ReservaException {

    private static final long serialVersionUID = 1L;

    public AnimalEnfermoException(String nombre, int salud, int saludMinima) {
        super("'" + nombre + "' no puede ser liberado: su salud es " + salud
                + " y necesita al menos " + saludMinima);
    }
}
