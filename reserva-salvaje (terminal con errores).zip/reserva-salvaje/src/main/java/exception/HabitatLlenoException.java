package exception;

import model.TipoHabitat;

/** El hábitat ya alcanzó su capacidad máxima de animales. */
public class HabitatLlenoException extends ReservaException {

    private static final long serialVersionUID = 1L;

    private final TipoHabitat habitat;

    public HabitatLlenoException(TipoHabitat habitat) {
        super("El habitat " + habitat + " esta lleno (capacidad maxima: " + habitat.getCapacidadMaxima() + ")");
        this.habitat = habitat;
    }

    public TipoHabitat getHabitat() { return habitat; }
}
