package exception;

/** Los datos de un animal no cumplen las reglas del juego (nombre vacío, edad negativa, etc.). */
public class DatosInvalidosException extends ReservaException {

    private static final long serialVersionUID = 1L;

    public DatosInvalidosException(String detalle) {
        super("Datos invalidos: " + detalle);
    }
}
