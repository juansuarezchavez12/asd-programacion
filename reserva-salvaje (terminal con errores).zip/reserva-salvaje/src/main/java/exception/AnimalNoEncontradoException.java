package exception;

/** No existe ningún animal con el id indicado. */
public class AnimalNoEncontradoException extends ReservaException {

    private static final long serialVersionUID = 1L;

    private final int id;

    public AnimalNoEncontradoException(int id) {
        super("No existe ningun animal con id " + id);
        this.id = id;
    }

    public int getId() { return id; }
}
