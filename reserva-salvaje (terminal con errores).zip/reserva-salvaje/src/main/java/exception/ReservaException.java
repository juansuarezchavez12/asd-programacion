package exception;

/**
 * Excepción base de todo el proyecto. Las excepciones propias del juego
 * (fondos insuficientes, hábitat lleno, etc.) van a heredar de esta clase,
 * así el Main puede capturarlas todas juntas o una por una.
 */
public class ReservaException extends Exception {

    private static final long serialVersionUID = 1L;

    public ReservaException(String mensaje) {
        super(mensaje);
    }

    public ReservaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
