package exception;

/** El presupuesto de la reserva no alcanza para pagar una operación. */
public class FondosInsuficientesException extends ReservaException {

    private static final long serialVersionUID = 1L;

    private final double requerido;
    private final double disponible;

    public FondosInsuficientesException(double requerido, double disponible) {
        super(String.format("Fondos insuficientes: se necesitan %.2f y la reserva tiene %.2f",
                requerido, disponible));
        this.requerido = requerido;
        this.disponible = disponible;
    }

    public double getRequerido() { return requerido; }
    public double getDisponible() { return disponible; }
}
