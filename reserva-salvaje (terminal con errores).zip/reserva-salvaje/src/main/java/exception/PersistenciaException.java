package exception;

/**
 * Se lanza cuando falla algo al hablar con la base de datos. El DAO captura
 * las SQLException y las relanza envueltas en esta excepción, para que las
 * capas superiores nunca dependan de JDBC.
 */
public class PersistenciaException extends ReservaException {

    private static final long serialVersionUID = 1L;

    public PersistenciaException(String mensaje) {
        super(mensaje);
    }

    public PersistenciaException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
