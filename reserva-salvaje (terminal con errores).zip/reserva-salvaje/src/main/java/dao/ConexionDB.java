package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Entrega conexiones a MySQL. Cada DAO pide una conexión por operación y la
 * cierra con try-with-resources, por lo que nunca queda una conexión abierta.
 *
 * Los valores por defecto se pueden cambiar acá o con las variables de
 * entorno DB_URL, DB_USER y DB_PASSWORD.
 */
public final class ConexionDB {

    private static final String URL = valor("DB_URL",
            "jdbc:mysql://localhost:3306/reserva_salvaje?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC");
    private static final String USUARIO = valor("DB_USER", "root");
    private static final String PASSWORD = valor("DB_PASSWORD", "");

    private ConexionDB() {
    }

    public static Connection getConexion() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }

    private static String valor(String variable, String porDefecto) {
        String valor = System.getenv(variable);
        return (valor == null || valor.isBlank()) ? porDefecto : valor;
    }
}
