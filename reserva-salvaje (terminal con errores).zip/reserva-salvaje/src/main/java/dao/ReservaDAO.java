package dao;

import exception.PersistenciaException;
import model.Reserva;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

/** Acceso a la tabla reserva, que tiene una única fila (id = 1) con el presupuesto. */
public class ReservaDAO {

    private static final int ID_RESERVA = 1;

    public Optional<Reserva> obtener() throws PersistenciaException {
        String sql = "SELECT id, nombre, presupuesto FROM reserva WHERE id = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, ID_RESERVA);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(new Reserva(rs.getInt("id"), rs.getString("nombre"),
                            rs.getDouble("presupuesto")));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo leer la reserva", e);
        }
    }

    public boolean actualizarPresupuesto(double nuevoPresupuesto) throws PersistenciaException {
        String sql = "UPDATE reserva SET presupuesto = ? WHERE id = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, nuevoPresupuesto);
            ps.setInt(2, ID_RESERVA);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo actualizar el presupuesto", e);
        }
    }
}
