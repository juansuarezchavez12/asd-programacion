package model;

/**
 * Comportamiento común de todo lo que la reserva puede atender.
 * El service la usa de forma polimórfica: recibe un Cuidable y opera sin
 * importar si es un carnívoro, un ave o cualquier otra subclase.
 */
public interface Cuidable {

    /** Da de comer al animal. Cada especie calma una cantidad distinta de hambre. */
    void alimentar();

    /** Recupera la cantidad de puntos de salud indicada (sin superar el máximo). */
    void curar(int puntos);

    /** Indica si el animal tiene demasiada hambre o muy poca salud. */
    boolean necesitaAtencion();

    /** Costo en dinero de alimentar y mantener al animal un día. */
    double calcularCostoDiario();
}
