package model;

/**
 * Identifica la subclase concreta de Animal. Es el valor que se guarda en la
 * columna "tipo" de la tabla animal, para que el DAO sepa qué clase instanciar.
 */
public enum TipoAnimal {
    CARNIVORO,
    HERBIVORO,
    AVE,
    REPTIL,
    ACUATICO
}
