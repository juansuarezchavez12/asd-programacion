package model;

/**
 * Hábitats disponibles en la reserva. Cada uno tiene una capacidad máxima
 * de animales, que más adelante validará el service.
 */
public enum TipoHabitat {
    SABANA(4),
    JAULA_SEGURIDAD(2),
    AVIARIO(3),
    TERRARIO(3),
    ACUARIO(2);

    private final int capacidadMaxima;

    TipoHabitat(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }
}
