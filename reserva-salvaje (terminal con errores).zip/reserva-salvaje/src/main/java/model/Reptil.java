package model;

/**
 * Reptil: necesita un terrario con temperatura controlada. Come poco (una
 * ración lo sacia casi por completo), pero calentar el terrario cuesta más
 * cuanto mayor sea su temperatura ideal.
 */
public class Reptil extends Animal {

    private static final double COSTO_BASE_DIARIO = 4.0;
    private static final double COSTO_POR_GRADO = 0.1;
    private static final double COSTO_RESCATE = 60.0;
    private static final int HAMBRE_QUE_CALMA_UNA_RACION = 60;

    private double temperaturaIdealC;

    public Reptil(String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                  double temperaturaIdealC) {
        super(nombre, edad, salud, hambre, habitat);
        this.temperaturaIdealC = temperaturaIdealC;
    }

    public Reptil(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                  double temperaturaIdealC) {
        super(id, nombre, edad, salud, hambre, habitat);
        this.temperaturaIdealC = temperaturaIdealC;
    }

    @Override
    public TipoAnimal getTipo() { return TipoAnimal.REPTIL; }

    @Override
    public TipoHabitat getHabitatRequerido() { return TipoHabitat.TERRARIO; }

    @Override
    public double getCostoRescate() { return COSTO_RESCATE; }

    @Override
    public double calcularCostoDiario() { return COSTO_BASE_DIARIO + temperaturaIdealC * COSTO_POR_GRADO; }

    @Override
    public void alimentar() { reducirHambre(HAMBRE_QUE_CALMA_UNA_RACION); }

    public double getTemperaturaIdealC() { return temperaturaIdealC; }
    public void setTemperaturaIdealC(double temperaturaIdealC) { this.temperaturaIdealC = temperaturaIdealC; }

    @Override
    public String toString() {
        return super.toString() + " [temperatura ideal: " + temperaturaIdealC + " C]";
    }
}
