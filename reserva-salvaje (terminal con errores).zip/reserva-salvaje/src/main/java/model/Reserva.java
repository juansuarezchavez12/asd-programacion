package model;

/** La reserva del jugador: guarda el presupuesto disponible. */
public class Reserva {

    private int id;
    private String nombre;
    private double presupuesto;

    public Reserva(int id, String nombre, double presupuesto) {
        this.id = id;
        this.nombre = nombre;
        this.presupuesto = presupuesto;
    }

    public boolean puedePagar(double monto) {
        return presupuesto >= monto;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }

    public double getPresupuesto() { return presupuesto; }
    public void setPresupuesto(double presupuesto) { this.presupuesto = presupuesto; }

    @Override
    public String toString() {
        return nombre + " (presupuesto: " + presupuesto + ")";
    }
}
