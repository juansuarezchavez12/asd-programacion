package model;

/**
 * Herbívoro: dieta de forraje (costo medio) y vive en la sabana junto a
 * otros herbívoros.
 */
public class Herbivoro extends Animal {

    private static final double PRECIO_KG_FORRAJE = 3.0;
    private static final double COSTO_RESCATE = 100.0;
    private static final int HAMBRE_QUE_CALMA_UNA_RACION = 30;

    private double kgForrajeDiarios;

    public Herbivoro(String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                     double kgForrajeDiarios) {
        super(nombre, edad, salud, hambre, habitat);
        this.kgForrajeDiarios = kgForrajeDiarios;
    }

    public Herbivoro(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                     double kgForrajeDiarios) {
        super(id, nombre, edad, salud, hambre, habitat);
        this.kgForrajeDiarios = kgForrajeDiarios;
    }

    @Override
    public TipoAnimal getTipo() { return TipoAnimal.HERBIVORO; }

    @Override
    public TipoHabitat getHabitatRequerido() { return TipoHabitat.SABANA; }

    @Override
    public double getCostoRescate() { return COSTO_RESCATE; }

    @Override
    public double calcularCostoDiario() { return kgForrajeDiarios * PRECIO_KG_FORRAJE; }

    @Override
    public void alimentar() { reducirHambre(HAMBRE_QUE_CALMA_UNA_RACION); }

    public double getKgForrajeDiarios() { return kgForrajeDiarios; }
    public void setKgForrajeDiarios(double kgForrajeDiarios) { this.kgForrajeDiarios = kgForrajeDiarios; }

    @Override
    public String toString() {
        return super.toString() + " [forraje diario: " + kgForrajeDiarios + " kg]";
    }
}
