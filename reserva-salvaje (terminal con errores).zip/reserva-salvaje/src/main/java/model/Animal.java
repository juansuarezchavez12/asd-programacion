package model;

/**
 * Clase base de la jerarquía. Reúne lo que comparten todos los animales
 * (identidad, salud, hambre, hábitat) y declara lo que cada especie debe
 * resolver a su manera: costo diario, costo de rescate, hábitat requerido
 * y cómo se alimenta.
 */
public abstract class Animal implements Cuidable {

    public static final int SALUD_MAXIMA = 100;
    public static final int HAMBRE_MAXIMA = 100;

    private static final int HAMBRE_QUE_REQUIERE_ATENCION = 60;
    private static final int SALUD_QUE_REQUIERE_ATENCION = 50;

    private int id; // 0 = todavía no fue guardado en la base
    private String nombre;
    private int edad;
    private int salud;
    private int hambre;
    private TipoHabitat habitat; // hábitat en el que el jugador decidió alojarlo

    /** Constructor para animales nuevos (todavía sin id). */
    protected Animal(String nombre, int edad, int salud, int hambre, TipoHabitat habitat) {
        this(0, nombre, edad, salud, hambre, habitat);
    }

    /** Constructor para animales leídos de la base de datos. */
    protected Animal(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
        this.salud = salud;
        this.hambre = hambre;
        this.habitat = habitat;
    }

    // ---- Lo que cada especie debe definir ----

    /** Subclase concreta; se guarda en la columna "tipo". */
    public abstract TipoAnimal getTipo();

    /** Hábitat que exige la especie. */
    public abstract TipoHabitat getHabitatRequerido();

    /** Dinero que cuesta rescatar a este animal. */
    public abstract double getCostoRescate();

    // calcularCostoDiario() y alimentar() vienen de Cuidable y cada subclase los implementa.

    // ---- Comportamiento común ----

    @Override
    public void curar(int puntos) {
        if (puntos > 0) {
            salud = Math.min(SALUD_MAXIMA, salud + puntos);
        }
    }

    @Override
    public boolean necesitaAtencion() {
        return hambre >= HAMBRE_QUE_REQUIERE_ATENCION || salud <= SALUD_QUE_REQUIERE_ATENCION;
    }

    /** Sube el hambre (por ejemplo, al pasar un día). */
    public void aumentarHambre(int puntos) {
        if (puntos > 0) {
            hambre = Math.min(HAMBRE_MAXIMA, hambre + puntos);
        }
    }

    /** Baja la salud (por ejemplo, por pasar hambre). */
    public void perderSalud(int puntos) {
        if (puntos > 0) {
            salud = Math.max(0, salud - puntos);
        }
    }

    /** Uso interno de las subclases: calma el hambre sin bajar de 0. */
    protected void reducirHambre(int puntos) {
        if (puntos > 0) {
            hambre = Math.max(0, hambre - puntos);
        }
    }

    // ---- Getters y setters ----

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdad() { return edad; }
    public void setEdad(int edad) { this.edad = edad; }

    public int getSalud() { return salud; }
    public void setSalud(int salud) { this.salud = salud; }

    public int getHambre() { return hambre; }
    public void setHambre(int hambre) { this.hambre = hambre; }

    public TipoHabitat getHabitat() { return habitat; }
    public void setHabitat(TipoHabitat habitat) { this.habitat = habitat; }

    @Override
    public String toString() {
        return getTipo() + " #" + id + " '" + nombre + "' (edad " + edad + ", salud " + salud
                + ", hambre " + hambre + ", habitat " + habitat + ")";
    }
}
