package service;

import dao.AnimalDAO;
import dao.ReservaDAO;
import exception.AnimalEnfermoException;
import exception.AnimalNoEncontradoException;
import exception.DatosInvalidosException;
import exception.FondosInsuficientesException;
import exception.HabitatIncompatibleException;
import exception.HabitatLlenoException;
import exception.PersistenciaException;
import exception.ReservaException;
import model.Animal;
import model.AnimalAcuatico;
import model.Ave;
import model.Carnivoro;
import model.Cuidable;
import model.Herbivoro;
import model.Reptil;
import model.Reserva;
import model.TipoHabitat;

import java.util.List;

/**
 * Reglas de negocio de Reserva Salvaje. Valida, decide y delega en los DAO;
 * no imprime nada ni conoce JDBC.
 *
 * Reglas que aplica (cada una con su excepción):
 *  1. Rescatar, alimentar o curar cuesta dinero           -> FondosInsuficientesException
 *  2. Cada hábitat tiene una capacidad máxima              -> HabitatLlenoException
 *  3. El animal va en el hábitat que exige su especie      -> HabitatIncompatibleException
 *  4. El id de un animal tiene que existir                 -> AnimalNoEncontradoException
 *  5. Solo se libera a un animal con salud suficiente      -> AnimalEnfermoException
 *  6. Los datos del animal tienen que ser válidos          -> DatosInvalidosException
 *  7. Cualquier falla de la base se traduce                -> PersistenciaException
 */
public class ReservaService {

    public static final double PRESUPUESTO_INICIAL = 1000.0;
    public static final int SALUD_MINIMA_PARA_LIBERAR = 60;
    public static final double COSTO_CURACION = 40.0;
    public static final int PUNTOS_CURACION = 30;

    private static final int LARGO_MAXIMO_NOMBRE = 50;
    private static final int HAMBRE_POR_DIA = 25;
    private static final int HAMBRE_CRITICA = 80;
    private static final int SALUD_PERDIDA_POR_HAMBRE = 15;
    private static final double DONACION_BASE = 20.0;
    private static final double DONACION_POR_ANIMAL_SANO = 10.0;

    /** Resultado de atender a todos los animales. */
    public record ResumenAtencion(int atendidos, int sinFondos, double gastoTotal) { }

    /** Resultado de pasar un día. */
    public record ResumenDia(int animalesEnHambreCritica, int animalesSanos, double donaciones) { }

    private final AnimalDAO animalDAO;
    private final ReservaDAO reservaDAO;

    public ReservaService() {
        this(new AnimalDAO(), new ReservaDAO());
    }

    public ReservaService(AnimalDAO animalDAO, ReservaDAO reservaDAO) {
        this.animalDAO = animalDAO;
        this.reservaDAO = reservaDAO;
    }

    // =====================================================================
    // Partida
    // =====================================================================

    /** Vacía la reserva y vuelve al presupuesto inicial. Permite repetir la demostración. */
    public void reiniciarJuego() throws ReservaException {
        animalDAO.eliminarTodos();
        if (!reservaDAO.actualizarPresupuesto(PRESUPUESTO_INICIAL)) {
            throw new PersistenciaException("No existe la fila de la reserva (ejecutar sql/schema.sql)");
        }
    }

    public double consultarPresupuesto() throws ReservaException {
        return obtenerReserva().getPresupuesto();
    }

    // =====================================================================
    // Altas y consultas
    // =====================================================================

    /** Rescata a un animal: valida datos, hábitat, capacidad y fondos, y lo guarda. */
    public void rescatarAnimal(Animal animal) throws ReservaException {
        validarDatos(animal);

        TipoHabitat habitat = animal.getHabitat();
        if (habitat != animal.getHabitatRequerido()) {
            throw new HabitatIncompatibleException(animal.getNombre(), animal.getTipo(),
                    habitat, animal.getHabitatRequerido());
        }
        if (animalDAO.contarPorHabitat(habitat) >= habitat.getCapacidadMaxima()) {
            throw new HabitatLlenoException(habitat);
        }
        Reserva reserva = obtenerReserva();
        verificarFondos(reserva, animal.getCostoRescate());

        animalDAO.insertar(animal);
        try {
            cobrar(reserva, animal.getCostoRescate());
        } catch (PersistenciaException e) {
            deshacerAlta(animal); // si no se pudo cobrar, el animal no debe quedar guardado gratis
            throw e;
        }
    }

    public Animal buscarAnimal(int id) throws ReservaException {
        return animalDAO.buscarPorId(id).orElseThrow(() -> new AnimalNoEncontradoException(id));
    }

    public List<Animal> listarAnimales() throws ReservaException {
        return animalDAO.listarTodos();
    }

    public List<Animal> listarPorHabitat(TipoHabitat habitat) throws ReservaException {
        if (habitat == null) {
            throw new DatosInvalidosException("hay que indicar un habitat");
        }
        return animalDAO.listarPorHabitat(habitat);
    }

    // =====================================================================
    // Cuidado de los animales
    // =====================================================================

    /** Alimenta a un animal pagando su costo diario. */
    public void alimentarAnimal(int id) throws ReservaException {
        Animal animal = buscarAnimal(id);
        Reserva reserva = obtenerReserva();
        double costo = animal.calcularCostoDiario();
        verificarFondos(reserva, costo);

        animal.alimentar();
        guardar(animal);
        cobrar(reserva, costo);
    }

    /** Cura a un animal (recupera salud) pagando el costo del tratamiento. */
    public void curarAnimal(int id) throws ReservaException {
        Animal animal = buscarAnimal(id);
        Reserva reserva = obtenerReserva();
        verificarFondos(reserva, COSTO_CURACION);

        animal.curar(PUNTOS_CURACION);
        guardar(animal);
        cobrar(reserva, COSTO_CURACION);
    }

    /**
     * MÉTODO POLIMÓRFICO: recibe la interfaz Cuidable y funciona igual para
     * cualquier subclase. Si el animal necesita atención, verifica fondos con
     * su costo diario (cada especie calcula el suyo), lo alimenta (cada
     * especie calma una cantidad distinta de hambre) y guarda el cambio.
     *
     * @return el dinero gastado (0 si no necesitaba atención)
     */
    public double atenderAnimal(Cuidable cuidable) throws ReservaException {
        if (cuidable == null) {
            throw new DatosInvalidosException("no hay ningun animal para atender");
        }
        if (!cuidable.necesitaAtencion()) {
            return 0;
        }
        Reserva reserva = obtenerReserva();
        double costo = cuidable.calcularCostoDiario();
        verificarFondos(reserva, costo);

        cuidable.alimentar();
        if (cuidable instanceof Animal animal) {
            guardar(animal);
        }
        cobrar(reserva, costo);
        return costo;
    }

    /** Atiende a todos los animales que lo necesitan; los que no se pueden pagar se cuentan aparte. */
    public ResumenAtencion atenderTodos() throws ReservaException {
        int atendidos = 0;
        int sinFondos = 0;
        double gasto = 0;
        for (Animal animal : animalDAO.listarTodos()) {
            try {
                double costo = atenderAnimal(animal);
                if (costo > 0) {
                    atendidos++;
                    gasto += costo;
                }
            } catch (FondosInsuficientesException e) {
                sinFondos++;
            }
        }
        return new ResumenAtencion(atendidos, sinFondos, redondear(gasto));
    }

    /** Libera a un animal recuperado. Devuelve el animal liberado. */
    public Animal liberarAnimal(int id) throws ReservaException {
        Animal animal = buscarAnimal(id);
        if (animal.getSalud() < SALUD_MINIMA_PARA_LIBERAR) {
            throw new AnimalEnfermoException(animal.getNombre(), animal.getSalud(), SALUD_MINIMA_PARA_LIBERAR);
        }
        animalDAO.eliminar(id);
        return animal;
    }

    /**
     * Pasa un día: sube el hambre de todos, los que llegan a hambre crítica
     * pierden salud, y la reserva recibe donaciones según los animales sanos.
     */
    public ResumenDia avanzarDia() throws ReservaException {
        int criticos = 0;
        int sanos = 0;
        for (Animal animal : animalDAO.listarTodos()) {
            animal.aumentarHambre(HAMBRE_POR_DIA);
            if (animal.getHambre() >= HAMBRE_CRITICA) {
                animal.perderSalud(SALUD_PERDIDA_POR_HAMBRE);
                criticos++;
            }
            if (animal.getSalud() >= SALUD_MINIMA_PARA_LIBERAR) {
                sanos++;
            }
            guardar(animal);
        }
        double donaciones = DONACION_BASE + DONACION_POR_ANIMAL_SANO * sanos;
        Reserva reserva = obtenerReserva();
        double nuevo = redondear(reserva.getPresupuesto() + donaciones);
        if (!reservaDAO.actualizarPresupuesto(nuevo)) {
            throw new PersistenciaException("No se pudo actualizar el presupuesto de la reserva");
        }
        return new ResumenDia(criticos, sanos, donaciones);
    }

    // =====================================================================
    // Auxiliares privados
    // =====================================================================

    private void validarDatos(Animal animal) throws DatosInvalidosException {
        if (animal == null) {
            throw new DatosInvalidosException("no se indico ningun animal");
        }
        String nombre = animal.getNombre();
        if (nombre == null || nombre.isBlank()) {
            throw new DatosInvalidosException("el nombre no puede estar vacio");
        }
        if (nombre.length() > LARGO_MAXIMO_NOMBRE) {
            throw new DatosInvalidosException("el nombre no puede superar los " + LARGO_MAXIMO_NOMBRE + " caracteres");
        }
        if (animal.getEdad() < 0) {
            throw new DatosInvalidosException("la edad no puede ser negativa (" + animal.getEdad() + ")");
        }
        if (animal.getSalud() < 0 || animal.getSalud() > Animal.SALUD_MAXIMA) {
            throw new DatosInvalidosException("la salud tiene que estar entre 0 y " + Animal.SALUD_MAXIMA
                    + " (" + animal.getSalud() + ")");
        }
        if (animal.getHambre() < 0 || animal.getHambre() > Animal.HAMBRE_MAXIMA) {
            throw new DatosInvalidosException("el hambre tiene que estar entre 0 y " + Animal.HAMBRE_MAXIMA
                    + " (" + animal.getHambre() + ")");
        }
        if (animal.getHabitat() == null) {
            throw new DatosInvalidosException("hay que indicar el habitat");
        }
        if (animal instanceof Carnivoro c && c.getKgCarneDiarios() <= 0) {
            throw new DatosInvalidosException("los kg de carne diarios deben ser mayores a 0");
        }
        if (animal instanceof Herbivoro h && h.getKgForrajeDiarios() <= 0) {
            throw new DatosInvalidosException("los kg de forraje diarios deben ser mayores a 0");
        }
        if (animal instanceof Ave a && a.getEnvergaduraCm() <= 0) {
            throw new DatosInvalidosException("la envergadura debe ser mayor a 0");
        }
        if (animal instanceof Reptil r && r.getTemperaturaIdealC() <= 0) {
            throw new DatosInvalidosException("la temperatura ideal debe ser mayor a 0");
        }
        if (animal instanceof AnimalAcuatico ac && ac.getProfundidadMinimaM() <= 0) {
            throw new DatosInvalidosException("la profundidad minima debe ser mayor a 0");
        }
    }

    private Reserva obtenerReserva() throws PersistenciaException {
        return reservaDAO.obtener().orElseThrow(
                () -> new PersistenciaException("No existe la reserva en la base (ejecutar sql/schema.sql)"));
    }

    private void verificarFondos(Reserva reserva, double monto) throws FondosInsuficientesException {
        if (!reserva.puedePagar(monto)) {
            throw new FondosInsuficientesException(monto, reserva.getPresupuesto());
        }
    }

    private void cobrar(Reserva reserva, double monto) throws PersistenciaException {
        double nuevo = redondear(reserva.getPresupuesto() - monto);
        if (!reservaDAO.actualizarPresupuesto(nuevo)) {
            throw new PersistenciaException("No se pudo actualizar el presupuesto de la reserva");
        }
        reserva.setPresupuesto(nuevo);
    }

    private void guardar(Animal animal) throws ReservaException {
        if (!animalDAO.actualizar(animal)) {
            throw new AnimalNoEncontradoException(animal.getId());
        }
    }

    private void deshacerAlta(Animal animal) {
        try {
            animalDAO.eliminar(animal.getId());
        } catch (PersistenciaException ignorada) {
            // mejor esfuerzo: ya se está informando el error original
        }
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}
