package main;

import dao.AnimalDAO;
import exception.ReservaException;
import model.Animal;
import model.AnimalAcuatico;
import model.Ave;
import model.Carnivoro;
import model.Cuidable;
import model.Herbivoro;
import model.Reptil;
import model.TipoHabitat;
import service.ReservaService;
import service.ReservaService.ResumenAtencion;
import service.ReservaService.ResumenDia;

import java.util.ArrayList;
import java.util.List;

/**
 * Recorre el juego completo de punta a punta y fuerza a propósito cada uno de
 * los errores de negocio para mostrar que se controlan. Cada vez que arranca
 * reinicia la partida, así se puede ejecutar todas las veces que haga falta.
 */
public class Main {

    /** Una acción que puede fallar con una excepción del juego. */
    @FunctionalInterface
    private interface Accion {
        void ejecutar() throws ReservaException;
    }

    public static void main(String[] args) {
        System.out.println("=== RESERVA SALVAJE ===");
        try {
            ejecutarJuego(new ReservaService(), new AnimalDAO());
        } catch (ReservaException e) {
            System.out.println();
            System.out.println("No se pudo completar la demostracion: " + e.getMessage());
            if (e.getCause() != null) {
                System.out.println("Causa: " + e.getCause().getMessage());
            }
            System.out.println("Revisar que MySQL este encendido, que se haya ejecutado sql/schema.sql "
                    + "y que la clave en ConexionDB sea correcta.");
        } catch (RuntimeException e) {
            System.out.println("Error inesperado: " + e);
        }
        System.out.println();
        System.out.println("=== FIN ===");
    }

    public static void ejecutarJuego(ReservaService service, AnimalDAO animalDAO) throws ReservaException {

        titulo("0. Preparacion: reiniciar la partida");
        service.reiniciarJuego();
        System.out.printf("Partida reiniciada. Presupuesto inicial: %.2f%n", service.consultarPresupuesto());

        // ------------------------------------------------------------------
        titulo("1. Rescatar animales (una de cada especie, mas algunos herbivoros)");
        Animal simba = new Carnivoro("Simba", 7, 90, 40, TipoHabitat.JAULA_SEGURIDAD, 5.0);
        Animal dumbo = new Herbivoro("Dumbo", 12, 80, 70, TipoHabitat.SABANA, 10.0);
        Animal pico = new Ave("Pico", 3, 70, 50, TipoHabitat.AVIARIO, 200, true);
        Animal rex = new Reptil("Rex", 5, 85, 65, TipoHabitat.TERRARIO, 30.0);
        Animal nemo = new AnimalAcuatico("Nemo", 2, 95, 45, TipoHabitat.ACUARIO, 3.0);
        Animal bambi = new Herbivoro("Bambi", 1, 75, 20, TipoHabitat.SABANA, 6.0);
        Animal tuco = new Herbivoro("Tuco", 9, 30, 30, TipoHabitat.SABANA, 8.0);
        Animal rocio = new Herbivoro("Rocio", 4, 80, 80, TipoHabitat.SABANA, 6.0);
        for (Animal animal : List.of(simba, dumbo, pico, rex, nemo, bambi, tuco, rocio)) {
            rescatar(service, animal, "");
        }

        // ------------------------------------------------------------------
        titulo("2. Errores de rescate FORZADOS a proposito");
        rescatar(service, new Herbivoro("", -3, 150, -5, TipoHabitat.SABANA, 10.0),
                "[error forzado: datos invalidos]");
        rescatar(service, new Ave("Kiwi", 2, 80, 30, TipoHabitat.ACUARIO, 60, false),
                "[error forzado: habitat incompatible]");
        rescatar(service, new Herbivoro("Gazela", 3, 90, 20, TipoHabitat.SABANA, 7.0),
                "[error forzado: habitat lleno]");
        rescatar(service, new Carnivoro("Luna", 5, 85, 40, TipoHabitat.JAULA_SEGURIDAD, 4.0),
                "[error forzado: fondos insuficientes]");

        // ------------------------------------------------------------------
        titulo("3. Animales de la reserva");
        intentar("Listar todos los animales", () -> {
            for (Animal animal : service.listarAnimales()) {
                System.out.println("   " + animal);
            }
            System.out.println("   En la SABANA hay " + service.listarPorHabitat(TipoHabitat.SABANA).size()
                    + " de " + TipoHabitat.SABANA.getCapacidadMaxima() + " lugares ocupados");
        });

        // ------------------------------------------------------------------
        titulo("4. Cuidar a los animales");
        intentar("Alimentar a Dumbo (herbivoro con hambre 70)", () -> {
            service.alimentarAnimal(dumbo.getId());
            Animal actual = service.buscarAnimal(dumbo.getId());
            System.out.printf("   Dumbo ahora tiene hambre %d | presupuesto: %.2f%n",
                    actual.getHambre(), service.consultarPresupuesto());
        });
        intentar("Atender a todos los que lo necesitan", () -> {
            ResumenAtencion resumen = service.atenderTodos();
            System.out.printf("   Atendidos: %d | sin fondos: %d | gasto: %.2f | presupuesto: %.2f%n",
                    resumen.atendidos(), resumen.sinFondos(), resumen.gastoTotal(), service.consultarPresupuesto());
        });

        // ------------------------------------------------------------------
        titulo("5. Errores de cuidado FORZADOS a proposito");
        intentar("Liberar a Tuco, que esta muy debil [error forzado: animal enfermo]", () -> {
            service.liberarAnimal(tuco.getId());
        });
        intentar("Curar a Tuco sin dinero suficiente [error forzado: fondos insuficientes]", () -> {
            service.curarAnimal(tuco.getId());
        });
        intentar("Buscar un animal que no existe [error forzado: animal no encontrado]", () -> {
            service.buscarAnimal(9999);
        });
        intentar("Alimentar a un animal que no existe [error forzado: animal no encontrado]", () -> {
            service.alimentarAnimal(9999);
        });

        // ------------------------------------------------------------------
        titulo("6. Pasa un dia");
        intentar("Avanzar el dia", () -> {
            ResumenDia dia = service.avanzarDia();
            System.out.printf("   Animales en hambre critica: %d | animales sanos: %d | donaciones: %.2f%n",
                    dia.animalesEnHambreCritica(), dia.animalesSanos(), dia.donaciones());
            System.out.printf("   Presupuesto: %.2f%n", service.consultarPresupuesto());
        });

        // ------------------------------------------------------------------
        titulo("7. Polimorfismo: atender por la interfaz Cuidable");
        intentar("Atender a Dumbo (Herbivoro), Pico (Ave) y Nemo (AnimalAcuatico) con el mismo metodo", () -> {
            List<Cuidable> cuidables = new ArrayList<>();
            cuidables.add(service.buscarAnimal(dumbo.getId()));
            cuidables.add(service.buscarAnimal(pico.getId()));
            cuidables.add(service.buscarAnimal(nemo.getId()));
            for (Cuidable cuidable : cuidables) {
                double gasto = service.atenderAnimal(cuidable);
                System.out.printf("   %s -> gasto %.2f%n", cuidable.getClass().getSimpleName(), gasto);
            }
            System.out.printf("   Presupuesto: %.2f%n", service.consultarPresupuesto());
        });

        // ------------------------------------------------------------------
        titulo("8. Recuperar y liberar a Tuco");
        intentar("Curar a Tuco", () -> {
            service.curarAnimal(tuco.getId());
            Animal actual = service.buscarAnimal(tuco.getId());
            System.out.printf("   Tuco ahora tiene salud %d | presupuesto: %.2f%n",
                    actual.getSalud(), service.consultarPresupuesto());
        });
        intentar("Liberar a Tuco", () -> {
            Animal liberado = service.liberarAnimal(tuco.getId());
            System.out.println("   " + liberado.getNombre() + " fue liberado. Vuelve a la naturaleza!");
        });

        // ------------------------------------------------------------------
        titulo("9. Error de base de datos FORZADO a proposito");
        intentar("Guardar un animal con salud 150 saltando la validacion del service "
                + "[error forzado: falla la base de datos]", () -> {
            animalDAO.insertar(new Herbivoro("Intruso", 3, 150, 20, TipoHabitat.SABANA, 5.0));
        });

        // ------------------------------------------------------------------
        titulo("10. Estado final de la reserva");
        intentar("Mostrar el estado final", () -> {
            for (Animal animal : service.listarAnimales()) {
                System.out.println("   " + animal);
            }
            System.out.printf("   Presupuesto final: %.2f%n", service.consultarPresupuesto());
        });
    }

    // ---------------------------------------------------------------
    // Auxiliares de presentacion
    // ---------------------------------------------------------------

    private static void rescatar(ReservaService service, Animal animal, String nota) {
        String descripcion = "Rescatar a '" + animal.getNombre() + "' (" + animal.getTipo() + ")"
                + (nota.isEmpty() ? "" : " " + nota);
        intentar(descripcion, () -> {
            service.rescatarAnimal(animal);
            System.out.printf("   OK -> id %d | presupuesto: %.2f%n", animal.getId(), service.consultarPresupuesto());
        });
    }

    /** Ejecuta la accion y, si falla con una excepcion del juego, la muestra sin cortar el programa. */
    private static void intentar(String descripcion, Accion accion) {
        System.out.println("> " + descripcion);
        try {
            accion.ejecutar();
        } catch (ReservaException e) {
            System.out.println("   ERROR CONTROLADO [" + e.getClass().getSimpleName() + "]: " + e.getMessage());
        }
    }

    private static void titulo(String texto) {
        System.out.println();
        System.out.println("--- " + texto + " ---");
    }
}
