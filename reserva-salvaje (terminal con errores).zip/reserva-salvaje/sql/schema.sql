-- Reserva Salvaje - esquema de la base de datos (MySQL 8.0 o superior)
-- Ejecutar completo antes de correr el programa.

CREATE DATABASE IF NOT EXISTS reserva_salvaje;
USE reserva_salvaje;

-- Tabla unica para toda la jerarquia de Animal.
-- La columna "tipo" indica que subclase es cada fila.
-- Las columnas propias de cada subclase quedan en NULL cuando no aplican.
CREATE TABLE IF NOT EXISTS animal (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo VARCHAR(20) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    edad INT NOT NULL,
    salud INT NOT NULL,
    hambre INT NOT NULL,
    habitat VARCHAR(20) NOT NULL,
    kg_carne DECIMAL(5,2) NULL,
    kg_forraje DECIMAL(5,2) NULL,
    envergadura_cm INT NULL,
    puede_volar BOOLEAN NULL,
    temperatura_ideal DECIMAL(4,1) NULL,
    profundidad_minima DECIMAL(5,2) NULL,
    CONSTRAINT chk_tipo CHECK (tipo IN ('CARNIVORO','HERBIVORO','AVE','REPTIL','ACUATICO')),
    CONSTRAINT chk_edad CHECK (edad >= 0),
    CONSTRAINT chk_salud CHECK (salud BETWEEN 0 AND 100),
    CONSTRAINT chk_hambre CHECK (hambre BETWEEN 0 AND 100)
);

-- Tabla con una unica fila: el presupuesto de la reserva.
CREATE TABLE IF NOT EXISTS reserva (
    id INT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL,
    presupuesto DECIMAL(10,2) NOT NULL,
    CONSTRAINT chk_presupuesto CHECK (presupuesto >= 0)
);

INSERT IGNORE INTO reserva (id, nombre, presupuesto) VALUES (1, 'Reserva Salvaje', 1000.00);
