package model;

/**
 * Carnívoro: el costo diario más alto (carne) y debe vivir aislado en una
 * jaula de seguridad, nunca junto a otras especies.
 */
public class Carnivoro extends Animal {

    private static final double PRECIO_KG_CARNE = 12.0;
    private static final double COSTO_RESCATE = 300.0;
    private static final int HAMBRE_QUE_CALMA_UNA_RACION = 50;

    private double kgCarneDiarios;

    public Carnivoro(String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                     double kgCarneDiarios) {
        super(nombre, edad, salud, hambre, habitat);
        this.kgCarneDiarios = kgCarneDiarios;
    }

    public Carnivoro(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                     double kgCarneDiarios) {
        super(id, nombre, edad, salud, hambre, habitat);
        this.kgCarneDiarios = kgCarneDiarios;
    }

    @Override
    public TipoAnimal getTipo() { return TipoAnimal.CARNIVORO; }

    @Override
    public TipoHabitat getHabitatRequerido() { return TipoHabitat.JAULA_SEGURIDAD; }

    @Override
    public double getCostoRescate() { return COSTO_RESCATE; }

    @Override
    public double calcularCostoDiario() { return kgCarneDiarios * PRECIO_KG_CARNE; }

    @Override
    public void alimentar() { reducirHambre(HAMBRE_QUE_CALMA_UNA_RACION); }

    public double getKgCarneDiarios() { return kgCarneDiarios; }
    public void setKgCarneDiarios(double kgCarneDiarios) { this.kgCarneDiarios = kgCarneDiarios; }

    @Override
    public String toString() {
        return super.toString() + " [carne diaria: " + kgCarneDiarios + " kg]";
    }
}
