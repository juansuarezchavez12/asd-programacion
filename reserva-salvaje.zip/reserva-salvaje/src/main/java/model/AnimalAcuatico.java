package model;

/**
 * Animal acuático: necesita un acuario con una profundidad mínima; su costo
 * diario incluye el mantenimiento del agua, que crece con la profundidad.
 */
public class AnimalAcuatico extends Animal {

    private static final double COSTO_BASE_DIARIO = 10.0;
    private static final double COSTO_POR_METRO = 2.0;
    private static final double COSTO_RESCATE = 250.0;
    private static final int HAMBRE_QUE_CALMA_UNA_RACION = 40;

    private double profundidadMinimaM;

    public AnimalAcuatico(String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                          double profundidadMinimaM) {
        super(nombre, edad, salud, hambre, habitat);
        this.profundidadMinimaM = profundidadMinimaM;
    }

    public AnimalAcuatico(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
                          double profundidadMinimaM) {
        super(id, nombre, edad, salud, hambre, habitat);
        this.profundidadMinimaM = profundidadMinimaM;
    }

    @Override
    public TipoAnimal getTipo() { return TipoAnimal.ACUATICO; }

    @Override
    public TipoHabitat getHabitatRequerido() { return TipoHabitat.ACUARIO; }

    @Override
    public double getCostoRescate() { return COSTO_RESCATE; }

    @Override
    public double calcularCostoDiario() { return COSTO_BASE_DIARIO + profundidadMinimaM * COSTO_POR_METRO; }

    @Override
    public void alimentar() { reducirHambre(HAMBRE_QUE_CALMA_UNA_RACION); }

    public double getProfundidadMinimaM() { return profundidadMinimaM; }
    public void setProfundidadMinimaM(double profundidadMinimaM) { this.profundidadMinimaM = profundidadMinimaM; }

    @Override
    public String toString() {
        return super.toString() + " [profundidad minima: " + profundidadMinimaM + " m]";
    }
}
