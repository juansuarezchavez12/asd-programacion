package model;

/**
 * Ave: necesita aviario. Su costo depende de la envergadura y de si puede
 * volar (un ave que no vuela requiere alimentación asistida, más cara).
 */
public class Ave extends Animal {

    private static final double COSTO_BASE_DIARIO = 8.0;
    private static final double RECARGO_SIN_VUELO = 4.0;
    private static final double COSTO_RESCATE = 120.0;
    private static final int HAMBRE_QUE_CALMA_UNA_RACION = 35;

    private int envergaduraCm;
    private boolean puedeVolar;

    public Ave(String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
               int envergaduraCm, boolean puedeVolar) {
        super(nombre, edad, salud, hambre, habitat);
        this.envergaduraCm = envergaduraCm;
        this.puedeVolar = puedeVolar;
    }

    public Ave(int id, String nombre, int edad, int salud, int hambre, TipoHabitat habitat,
               int envergaduraCm, boolean puedeVolar) {
        super(id, nombre, edad, salud, hambre, habitat);
        this.envergaduraCm = envergaduraCm;
        this.puedeVolar = puedeVolar;
    }

    @Override
    public TipoAnimal getTipo() { return TipoAnimal.AVE; }

    @Override
    public TipoHabitat getHabitatRequerido() { return TipoHabitat.AVIARIO; }

    @Override
    public double getCostoRescate() { return COSTO_RESCATE; }

    @Override
    public double calcularCostoDiario() {
        double costo = COSTO_BASE_DIARIO + envergaduraCm / 50.0;
        return puedeVolar ? costo : costo + RECARGO_SIN_VUELO;
    }

    @Override
    public void alimentar() { reducirHambre(HAMBRE_QUE_CALMA_UNA_RACION); }

    public int getEnvergaduraCm() { return envergaduraCm; }
    public void setEnvergaduraCm(int envergaduraCm) { this.envergaduraCm = envergaduraCm; }

    public boolean isPuedeVolar() { return puedeVolar; }
    public void setPuedeVolar(boolean puedeVolar) { this.puedeVolar = puedeVolar; }

    @Override
    public String toString() {
        return super.toString() + " [envergadura: " + envergaduraCm + " cm, puede volar: " + puedeVolar + "]";
    }
}
