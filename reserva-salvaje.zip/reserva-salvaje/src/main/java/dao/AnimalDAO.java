package dao;

import exception.PersistenciaException;
import model.Animal;
import model.AnimalAcuatico;
import model.Ave;
import model.Carnivoro;
import model.Herbivoro;
import model.Reptil;
import model.TipoAnimal;
import model.TipoHabitat;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Acceso a la tabla animal. Como toda la jerarquía vive en una sola tabla,
 * este DAO guarda cada subclase con su columna "tipo" y, al leer, usa esa
 * columna para crear el objeto de la clase correcta.
 */
public class AnimalDAO {

    private static final String COLUMNAS = "id, tipo, nombre, edad, salud, hambre, habitat, "
            + "kg_carne, kg_forraje, envergadura_cm, puede_volar, temperatura_ideal, profundidad_minima";

    // ---------------- ALTA ----------------

    /** Inserta el animal y deja en el objeto el id generado por MySQL. */
    public void insertar(Animal animal) throws PersistenciaException {
        validarAnimal(animal);
        String sql = "INSERT INTO animal (tipo, nombre, edad, salud, hambre, habitat, kg_carne, kg_forraje, "
                + "envergadura_cm, puede_volar, temperatura_ideal, profundidad_minima) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, animal.getTipo().name());
            ps.setString(2, animal.getNombre());
            ps.setInt(3, animal.getEdad());
            ps.setInt(4, animal.getSalud());
            ps.setInt(5, animal.getHambre());
            ps.setString(6, animal.getHabitat().name());
            cargarColumnasEspecificas(ps, animal, 7);
            ps.executeUpdate();
            try (ResultSet claves = ps.getGeneratedKeys()) {
                if (claves.next()) {
                    animal.setId(claves.getInt(1));
                }
            }
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo guardar al animal '" + animal.getNombre() + "'", e);
        }
    }

    // ---------------- LECTURA ----------------

    public Optional<Animal> buscarPorId(int id) throws PersistenciaException {
        String sql = "SELECT " + COLUMNAS + " FROM animal WHERE id = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return Optional.of(mapear(rs));
                }
                return Optional.empty();
            }
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo buscar al animal con id " + id, e);
        }
    }

    public List<Animal> listarTodos() throws PersistenciaException {
        String sql = "SELECT " + COLUMNAS + " FROM animal ORDER BY id";
        List<Animal> animales = new ArrayList<>();
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                animales.add(mapear(rs));
            }
            return animales;
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo listar a los animales", e);
        }
    }

    public List<Animal> listarPorHabitat(TipoHabitat habitat) throws PersistenciaException {
        if (habitat == null) {
            throw new PersistenciaException("El hábitat a consultar no puede ser nulo");
        }
        String sql = "SELECT " + COLUMNAS + " FROM animal WHERE habitat = ? ORDER BY id";
        List<Animal> animales = new ArrayList<>();
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, habitat.name());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    animales.add(mapear(rs));
                }
            }
            return animales;
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo listar a los animales del hábitat " + habitat, e);
        }
    }

    public int contarPorHabitat(TipoHabitat habitat) throws PersistenciaException {
        if (habitat == null) {
            throw new PersistenciaException("El hábitat a consultar no puede ser nulo");
        }
        String sql = "SELECT COUNT(*) FROM animal WHERE habitat = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, habitat.name());
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo contar a los animales del hábitat " + habitat, e);
        }
    }

    // ---------------- MODIFICACIÓN ----------------

    /** Actualiza todos los datos del animal (menos su tipo). Devuelve false si el id no existe. */
    public boolean actualizar(Animal animal) throws PersistenciaException {
        validarAnimal(animal);
        String sql = "UPDATE animal SET nombre = ?, edad = ?, salud = ?, hambre = ?, habitat = ?, "
                + "kg_carne = ?, kg_forraje = ?, envergadura_cm = ?, puede_volar = ?, "
                + "temperatura_ideal = ?, profundidad_minima = ? WHERE id = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, animal.getNombre());
            ps.setInt(2, animal.getEdad());
            ps.setInt(3, animal.getSalud());
            ps.setInt(4, animal.getHambre());
            ps.setString(5, animal.getHabitat().name());
            cargarColumnasEspecificas(ps, animal, 6);
            ps.setInt(12, animal.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo actualizar al animal con id " + animal.getId(), e);
        }
    }

    // ---------------- BAJA ----------------

    /** Elimina al animal. Devuelve false si el id no existe. */
    public boolean eliminar(int id) throws PersistenciaException {
        String sql = "DELETE FROM animal WHERE id = ?";
        try (Connection con = ConexionDB.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            throw new PersistenciaException("No se pudo eliminar al animal con id " + id, e);
        }
    }

    // ---------------- AUXILIARES ----------------

    private void validarAnimal(Animal animal) throws PersistenciaException {
        if (animal == null) {
            throw new PersistenciaException("No se puede guardar un animal nulo");
        }
        if (animal.getHabitat() == null) {
            throw new PersistenciaException("El animal '" + animal.getNombre() + "' no tiene hábitat asignado");
        }
    }

    /**
     * Carga las 6 columnas propias de las subclases, a partir del parámetro
     * "desde": kg_carne, kg_forraje, envergadura_cm, puede_volar,
     * temperatura_ideal y profundidad_minima. Las que no corresponden al
     * tipo del animal quedan en NULL.
     */
    private void cargarColumnasEspecificas(PreparedStatement ps, Animal animal, int desde) throws SQLException {
        ps.setNull(desde, Types.DECIMAL);
        ps.setNull(desde + 1, Types.DECIMAL);
        ps.setNull(desde + 2, Types.INTEGER);
        ps.setNull(desde + 3, Types.BOOLEAN);
        ps.setNull(desde + 4, Types.DECIMAL);
        ps.setNull(desde + 5, Types.DECIMAL);

        if (animal instanceof Carnivoro c) {
            ps.setDouble(desde, c.getKgCarneDiarios());
        } else if (animal instanceof Herbivoro h) {
            ps.setDouble(desde + 1, h.getKgForrajeDiarios());
        } else if (animal instanceof Ave a) {
            ps.setInt(desde + 2, a.getEnvergaduraCm());
            ps.setBoolean(desde + 3, a.isPuedeVolar());
        } else if (animal instanceof Reptil r) {
            ps.setDouble(desde + 4, r.getTemperaturaIdealC());
        } else if (animal instanceof AnimalAcuatico ac) {
            ps.setDouble(desde + 5, ac.getProfundidadMinimaM());
        }
    }

    /** Convierte la fila actual del ResultSet en la subclase que indica la columna "tipo". */
    private Animal mapear(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String nombre = rs.getString("nombre");
        int edad = rs.getInt("edad");
        int salud = rs.getInt("salud");
        int hambre = rs.getInt("hambre");

        TipoAnimal tipo;
        TipoHabitat habitat;
        try {
            tipo = TipoAnimal.valueOf(rs.getString("tipo"));
            habitat = TipoHabitat.valueOf(rs.getString("habitat"));
        } catch (IllegalArgumentException | NullPointerException e) {
            throw new SQLException("La fila del animal con id " + id + " tiene un tipo o hábitat inválido", e);
        }

        return switch (tipo) {
            case CARNIVORO -> new Carnivoro(id, nombre, edad, salud, hambre, habitat, rs.getDouble("kg_carne"));
            case HERBIVORO -> new Herbivoro(id, nombre, edad, salud, hambre, habitat, rs.getDouble("kg_forraje"));
            case AVE -> new Ave(id, nombre, edad, salud, hambre, habitat,
                    rs.getInt("envergadura_cm"), rs.getBoolean("puede_volar"));
            case REPTIL -> new Reptil(id, nombre, edad, salud, hambre, habitat, rs.getDouble("temperatura_ideal"));
            case ACUATICO -> new AnimalAcuatico(id, nombre, edad, salud, hambre, habitat,
                    rs.getDouble("profundidad_minima"));
        };
    }
}
