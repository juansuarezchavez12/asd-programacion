package main;

import dao.AnimalDAO;
import dao.ReservaDAO;
import exception.ReservaException;
import model.Animal;
import model.AnimalAcuatico;
import model.Ave;
import model.Carnivoro;
import model.Cuidable;
import model.Herbivoro;
import model.Reptil;
import model.Reserva;
import model.TipoHabitat;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Main PROVISORIO para la entrega de avance. Muestra que:
 *   1) la jerarquía y la interfaz Cuidable funcionan (sin base de datos);
 *   2) el modelo se puede guardar y recuperar de MySQL mediante el DAO.
 * El flujo completo con el service y los errores forzados viene después.
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("=== RESERVA SALVAJE - AVANCE ===");

        probarModelo();

        try {
            probarPersistencia();
        } catch (ReservaException e) {
            System.out.println();
            System.out.println("Error controlado: " + e.getMessage());
            if (e.getCause() != null) {
                System.out.println("Causa: " + e.getCause().getMessage());
            }
            System.out.println("Revisar que MySQL este encendido, que se haya ejecutado sql/schema.sql "
                    + "y que usuario/clave sean correctos (ver ConexionDB).");
        }

        System.out.println();
        System.out.println("=== FIN ===");
    }

    // ---------------------------------------------------------------
    // Parte 1: jerarquía + interfaz (no necesita base de datos)
    // ---------------------------------------------------------------
    private static void probarModelo() {
        System.out.println();
        System.out.println("--- 1. Jerarquia de clases ---");
        List<Animal> animales = crearAnimalesDePrueba();
        for (Animal a : animales) {
            System.out.println(a);
            System.out.printf("   habitat requerido: %s | rescate: %.2f | costo diario: %.2f%n",
                    a.getHabitatRequerido(), a.getCostoRescate(), a.calcularCostoDiario());
        }

        System.out.println();
        System.out.println("--- 2. Interfaz Cuidable (polimorfismo) ---");
        List<Cuidable> cuidables = new ArrayList<>(animales);
        for (Cuidable c : cuidables) {
            c.alimentar(); // cada especie calma una cantidad distinta de hambre
        }
        for (Animal a : animales) {
            System.out.println("Despues de alimentar: " + a.getNombre() + " -> hambre " + a.getHambre()
                    + ", necesita atencion: " + a.necesitaAtencion());
        }
    }

    // ---------------------------------------------------------------
    // Parte 2: guardar y recuperar con el DAO
    // ---------------------------------------------------------------
    private static void probarPersistencia() throws ReservaException {
        AnimalDAO animalDAO = new AnimalDAO();
        ReservaDAO reservaDAO = new ReservaDAO();

        System.out.println();
        System.out.println("--- 3. Guardar en MySQL (INSERT) ---");
        List<Animal> nuevos = crearAnimalesDePrueba();
        for (Animal a : nuevos) {
            animalDAO.insertar(a);
            System.out.println("Guardado con id " + a.getId() + ": " + a.getNombre());
        }

        System.out.println();
        System.out.println("--- 4. Recuperar uno por id (SELECT) ---");
        Animal primero = nuevos.get(0);
        Optional<Animal> recuperado = animalDAO.buscarPorId(primero.getId());
        if (recuperado.isPresent()) {
            System.out.println("Recuperado: " + recuperado.get());
        } else {
            System.out.println("No se encontro al animal con id " + primero.getId());
        }

        System.out.println();
        System.out.println("--- 5. Listar todos ---");
        for (Animal a : animalDAO.listarTodos()) {
            System.out.println(a);
        }

        System.out.println();
        System.out.println("--- 6. Actualizar (alimentar y volver a leer) ---");
        if (recuperado.isPresent()) {
            Animal animal = recuperado.get();
            int hambreAntes = animal.getHambre();
            animal.alimentar();
            animalDAO.actualizar(animal);
            animalDAO.buscarPorId(animal.getId()).ifPresent(a ->
                    System.out.println(a.getNombre() + ": hambre " + hambreAntes + " -> " + a.getHambre()));
        }

        System.out.println();
        System.out.println("--- 7. Consultas por habitat y reserva ---");
        System.out.println("Animales en SABANA: " + animalDAO.contarPorHabitat(TipoHabitat.SABANA));
        System.out.println("Animales en AVIARIO: " + animalDAO.listarPorHabitat(TipoHabitat.AVIARIO).size());
        Optional<Reserva> reserva = reservaDAO.obtener();
        System.out.println(reserva.isPresent() ? "Reserva: " + reserva.get()
                : "No hay una reserva cargada (ejecutar sql/schema.sql)");
    }

    private static List<Animal> crearAnimalesDePrueba() {
        List<Animal> animales = new ArrayList<>();
        animales.add(new Carnivoro("Simba", 7, 90, 40, TipoHabitat.JAULA_SEGURIDAD, 5.0));
        animales.add(new Herbivoro("Dumbo", 12, 80, 70, TipoHabitat.SABANA, 10.0));
        animales.add(new Ave("Pico", 3, 70, 50, TipoHabitat.AVIARIO, 200, true));
        animales.add(new Reptil("Rex", 5, 85, 65, TipoHabitat.TERRARIO, 30.0));
        animales.add(new AnimalAcuatico("Nemo", 2, 95, 45, TipoHabitat.ACUARIO, 3.0));
        return animales;
    }
}
